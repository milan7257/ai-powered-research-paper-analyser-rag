"""Quick terminal demo:  python run_cli.py sample/sample_paper.txt   (or a .pdf)"""
import sys
from rag_engine import PaperAnalyzer, evaluate

path = sys.argv[1] if len(sys.argv) > 1 else "sample/sample_paper.txt"
pa = PaperAnalyzer(use_dense=False)          # set True if sentence-transformers installed
if path.endswith(".txt"):
    n = pa.load(open(path, encoding="utf-8").read(), is_text=True)
else:
    n = pa.load(path)
print(f"Indexed {n} chunks | backend: {pa.index.backend}")
print("Keywords:", ", ".join(pa.keywords()), "\n")

for name, res in pa.full_report().items():
    print(f"=== {name} [{res['mode']}] ===\n{res['answer']}\n")

print("Retrieval hit-rate@3:", evaluate(pa, [
    ("What BLEU score was achieved on English-German?", "28.4"),
    ("Which optimizer was used?", "Adam"),
    ("How is word order handled?", "positional"),
    ("What are the limitations?", "quadratically"),
    ("What is future work?", "modalities"),
], k=3))
