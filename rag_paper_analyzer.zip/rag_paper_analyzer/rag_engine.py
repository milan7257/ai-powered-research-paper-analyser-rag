"""
rag_engine.py - Core RAG pipeline for the AI-Powered Research Paper Analyzer.

Pipeline:  PDF -> text -> cleaning -> chunking -> embeddings -> vector index
           -> retrieval (top-k) -> prompt building -> answer generation

Works OFFLINE out of the box (TF-IDF retrieval + extractive answers).
Upgrades automatically if you install/enable:
  * sentence-transformers  -> dense semantic embeddings
  * ANTHROPIC_API_KEY      -> LLM-generated answers (Claude)
"""
import os
import re
from dataclasses import dataclass
from typing import List, Optional

import numpy as np
from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# ----------------------------------------------------------------- 1. LOADING
def load_pdf(path_or_file) -> str:
    """Extract raw text from a PDF (path or file-like object)."""
    reader = PdfReader(path_or_file)
    pages = []
    for i, page in enumerate(reader.pages):
        txt = page.extract_text() or ""
        pages.append(f"[[PAGE {i + 1}]]\n{txt}")
    return "\n".join(pages)


def clean_text(text: str) -> str:
    text = re.sub(r"-\n(\w)", r"\1", text)          # fix hyphenated line breaks
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


# ---------------------------------------------------------------- 2. CHUNKING
@dataclass
class Chunk:
    id: int
    text: str
    page: int
    section: str


SECTION_RE = re.compile(
    r"^\s*(?:\d+\.?\s*)?(abstract|introduction|related work|background|methodology|"
    r"methods?|approach|experiments?|results?|discussion|conclusions?|future work|"
    r"limitations|references)\s*$",
    re.I,
)


def chunk_text(text: str, chunk_size: int = 120, overlap: int = 30) -> List[Chunk]:
    """Word-based sliding window chunking that remembers page + section."""
    chunks, page, section, buf, cid = [], 1, "Unknown", [], 0

    def flush():
        nonlocal buf, cid
        if buf:
            chunks.append(Chunk(cid, " ".join(buf), page, section))
            cid += 1
            buf = buf[-overlap:] if len(buf) > overlap else []

    for line in text.split("\n"):
        m = re.match(r"\[\[PAGE (\d+)\]\]", line)
        if m:
            page = int(m.group(1))
            continue
        if SECTION_RE.match(line):
            flush(); buf = []
            section = line.strip().title()
            continue
        for w in line.split():
            buf.append(w)
            if len(buf) >= chunk_size:
                flush()
    flush()
    # drop tiny trailing chunks that are pure overlap
    return [c for c in chunks if len(c.text.split()) > 15]


# ------------------------------------------------------- 3. EMBEDDING + INDEX
class VectorIndex:
    """Vector store with two backends: dense (sentence-transformers) or TF-IDF."""

    def __init__(self, use_dense: bool = True):
        self.backend = "tfidf"
        self.model = None
        if use_dense:
            try:
                from sentence_transformers import SentenceTransformer
                self.model = SentenceTransformer("all-MiniLM-L6-v2")
                self.backend = "dense (all-MiniLM-L6-v2)"
            except Exception:
                self.model = None
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2),
                                          sublinear_tf=True)
        self.matrix = None
        self.chunks: List[Chunk] = []

    def build(self, chunks: List[Chunk]):
        self.chunks = chunks
        texts = [c.text for c in chunks]
        if self.model is not None:
            self.matrix = self.model.encode(texts, normalize_embeddings=True)
        else:
            self.matrix = self.vectorizer.fit_transform(texts)

    def search(self, query: str, k: int = 4, boost: tuple = ()):
        if self.model is not None:
            q = self.model.encode([query], normalize_embeddings=True)
            scores = (self.matrix @ q.T).ravel()
        else:
            q = self.vectorizer.transform([query])
            scores = cosine_similarity(q, self.matrix).ravel()
        scores = scores.copy()
        for i, c in enumerate(self.chunks):          # hybrid: semantic + section prior
            if any(b in c.section.lower() for b in boost):
                scores[i] += 0.6
        top = np.argsort(scores)[::-1][:k]
        return [(self.chunks[i], float(scores[i])) for i in top]


# -------------------------------------------------------------- 4. GENERATION
def build_prompt(question: str, hits) -> str:
    ctx = "\n\n".join(
        f"[Source {i+1} | page {c.page} | {c.section}]\n{c.text}"
        for i, (c, _) in enumerate(hits)
    )
    return (
        "You are a research assistant. Answer ONLY from the context below. "
        "Cite sources like [Source 1]. If the answer is not in the context, say so.\n\n"
        f"CONTEXT:\n{ctx}\n\nQUESTION: {question}\n\nANSWER:"
    )


def _sentences(text: str):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if len(s.split()) > 5]


def extractive_answer(question: str, hits, n: int = 3) -> str:
    """Offline fallback: pick the sentences from retrieved chunks most similar to the question."""
    cands = []
    for i, (c, _) in enumerate(hits):
        for s in _sentences(c.text):
            cands.append((s, i + 1, 1.0 / (1 + 0.5 * i)))   # rank weight
    if not cands:
        return "I could not find an answer in the paper."
    vec = TfidfVectorizer(stop_words="english").fit([question] + [c[0] for c in cands])
    sc = cosine_similarity(vec.transform([question]), vec.transform([c[0] for c in cands])).ravel()
    sc = sc * np.array([c[2] for c in cands]) + np.array([c[2] for c in cands]) * 0.1
    best = np.argsort(sc)[::-1][:n]
    return " ".join(f"{cands[i][0]} [Source {cands[i][1]}]" for i in sorted(best))


def llm_answer(prompt: str) -> Optional[str]:
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return None
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)
        msg = client.messages.create(
            model=os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6"),
            max_tokens=700,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.content[0].text
    except Exception as e:
        return f"(LLM call failed: {e})"


# --------------------------------------------------------- 5. HIGH-LEVEL API
class PaperAnalyzer:
    def __init__(self, use_dense: bool = True):
        self.index = VectorIndex(use_dense)
        self.text = ""

    def load(self, source, is_text: bool = False):
        raw = source if is_text else load_pdf(source)
        self.text = clean_text(raw)
        chunks = chunk_text(self.text)
        if not chunks:
            raise ValueError("No readable text found (scanned PDF? try OCR).")
        self.index.build(chunks)
        return len(chunks)

    def ask(self, question: str, k: int = 4, boost: tuple = ()):
        hits = self.index.search(question, k, boost)
        prompt = build_prompt(question, hits)
        answer = llm_answer(prompt)
        mode = "LLM (Claude)"
        if answer is None:
            answer, mode = extractive_answer(question, hits), "Extractive (offline)"
        return {"answer": answer, "mode": mode, "sources": hits}

    # --- one-click analyses built on top of retrieval ---
    ANALYSES = {
        "Summary": ("What is the main objective, method and key findings of this paper?", ("abstract", "conclusion")),
        "Methodology": ("What methodology, model, algorithm or dataset does the paper use?", ("method", "approach")),
        "Results": ("What are the main results, metrics and performance numbers?", ("result", "experiment")),
        "Limitations": ("What limitations, challenges or weaknesses are mentioned?", ("limitation", "discussion")),
        "Future Work": ("What future work or improvements are suggested?", ("conclusion", "future")),
    }

    def full_report(self):
        return {name: self.ask(q, boost=b) for name, (q, b) in self.ANALYSES.items()}

    def keywords(self, n: int = 12):
        v = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_features=500)
        X = v.fit_transform([c.text for c in self.index.chunks])
        scores = np.asarray(X.sum(axis=0)).ravel()
        terms = np.array(v.get_feature_names_out())
        return list(terms[np.argsort(scores)[::-1][:n]])


# ------------------------------------------------------------------ 6. EVAL
def evaluate(analyzer: PaperAnalyzer, qa_pairs, k: int = 4):
    """Hit-rate@k: does a retrieved chunk contain the expected keyword?"""
    hits_ok = 0
    for q, kw in qa_pairs:
        res = analyzer.index.search(q, k)
        if any(kw.lower() in c.text.lower() for c, _ in res):
            hits_ok += 1
    return hits_ok / len(qa_pairs)
