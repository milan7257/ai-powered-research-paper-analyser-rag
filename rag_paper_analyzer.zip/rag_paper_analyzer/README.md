# AI-Powered Research Paper Analyzer using RAG

## 1. Abstract
Reading research papers is slow. This project builds a Retrieval-Augmented Generation (RAG) system that ingests a paper (PDF), splits it into section-aware chunks, indexes them in a vector store, and answers questions or produces an automatic analysis (summary, methodology, results, limitations, future work) **grounded in retrieved passages with citations**, which reduces hallucination.

## 2. Problem Statement
General LLMs may hallucinate and cannot read your private PDFs. RAG fixes this by retrieving relevant text first, then answering only from it.

## 3. Architecture
```
PDF -> Text extraction (pypdf) -> Cleaning -> Section/page-aware chunking (120 words, 30 overlap)
    -> Embeddings (TF-IDF or MiniLM) -> Vector index -> Query
    -> Top-k retrieval (cosine similarity + section boost)
    -> Prompt (context + question) -> LLM (Claude) or extractive fallback
    -> Answer + citations [Source n, page, section]
```

## 4. Tech Stack
Python, pypdf, scikit-learn (TF-IDF, cosine similarity), sentence-transformers (optional), Anthropic API (optional), Streamlit.

## 5. How to run
```
pip install -r requirements.txt
python run_cli.py                 # terminal demo on sample paper
streamlit run app.py              # web app
export ANTHROPIC_API_KEY=...      # optional: LLM answers
```

## 6. Key design choices
- **Section-aware chunking**: keeps page + section metadata for citations.
- **Hybrid retrieval**: similarity score + prior boost for the matching section (e.g. "Limitations").
- **Graceful fallback**: works offline (TF-IDF + extractive answers); upgrades to dense embeddings and LLM generation when available.
- **Grounded prompt**: "answer only from context, cite sources".

## 7. Evaluation
Retrieval Hit-Rate@k on question/keyword pairs (`evaluate()` in rag_engine.py). On the sample paper: **Hit-Rate@3 = 1.0** (5/5). For a real report, build 15-20 questions on 2-3 papers and compare TF-IDF vs MiniLM.

## 8. Limitations
Scanned PDFs need OCR; two-column layouts can jumble text; extractive mode cannot synthesize; tables/figures are not parsed.

## 9. Future work
FAISS/Chroma vector DB, cross-encoder re-ranking, multi-paper comparison, OCR (Tesseract), table extraction, citation graph, RAGAS evaluation.

## 10. Viva questions
- What is RAG and why use it over fine-tuning? (fresh/private data, citations, cheaper, less hallucination)
- Why chunk with overlap? (avoid cutting context at boundaries)
- TF-IDF vs dense embeddings? (lexical match vs semantic meaning)
- What is cosine similarity? (angle between vectors, ignores length)
- How do you reduce hallucination? (grounded prompt, top-k context, citations, "say if not found")
- How would you evaluate? (hit-rate@k, MRR, faithfulness, answer relevance)
