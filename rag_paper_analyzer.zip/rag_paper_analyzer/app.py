"""Streamlit UI:  streamlit run app.py"""
import streamlit as st
from rag_engine import PaperAnalyzer

st.set_page_config(page_title="AI Research Paper Analyzer", page_icon="📄", layout="wide")
st.title("📄 AI-Powered Research Paper Analyzer (RAG)")
st.caption("Upload a research paper PDF, get an instant analysis, and chat with it. Answers are grounded in retrieved passages with citations.")

with st.sidebar:
    st.header("Settings")
    use_dense = st.checkbox("Use dense embeddings (sentence-transformers)", value=False,
                            help="Needs `pip install sentence-transformers`. Falls back to TF-IDF if missing.")
    k = st.slider("Chunks retrieved (top-k)", 2, 8, 4)
    st.markdown("**LLM mode:** set `ANTHROPIC_API_KEY` env var for generated answers; otherwise extractive answers are used.")

up = st.file_uploader("Upload research paper (PDF)", type="pdf")
use_sample = st.button("Or try the sample paper")

if up or use_sample:
    key = up.name if up else "sample"
    if st.session_state.get("key") != key:
        pa = PaperAnalyzer(use_dense)
        with st.spinner("Reading, chunking and indexing..."):
            if up:
                n = pa.load(up)
            else:
                n = pa.load(open("sample/sample_paper.txt", encoding="utf-8").read(), is_text=True)
        st.session_state.update(key=key, pa=pa, n=n, chat=[], report=None)

if "pa" in st.session_state:
    pa = st.session_state["pa"]
    st.success(f"Indexed {st.session_state['n']} chunks • retrieval backend: {pa.index.backend}")
    tab1, tab2, tab3 = st.tabs(["📊 Auto Analysis", "💬 Ask the Paper", "🔎 Keywords & Stats"])

    with tab1:
        if st.button("Generate full analysis"):
            with st.spinner("Analyzing..."):
                st.session_state["report"] = pa.full_report()
        if st.session_state.get("report"):
            for name, res in st.session_state["report"].items():
                with st.expander(f"{name}  ·  {res['mode']}", expanded=True):
                    st.write(res["answer"])

    with tab2:
        for q, r in st.session_state["chat"]:
            st.chat_message("user").write(q)
            st.chat_message("assistant").write(r["answer"])
        q = st.chat_input("Ask a question about the paper...")
        if q:
            r = pa.ask(q, k)
            st.session_state["chat"].append((q, r))
            st.chat_message("user").write(q)
            st.chat_message("assistant").write(r["answer"])
            with st.expander("Retrieved sources"):
                for i, (c, sc) in enumerate(r["sources"], 1):
                    st.markdown(f"**Source {i}** · page {c.page} · {c.section} · score {sc:.2f}")
                    st.caption(c.text)

    with tab3:
        st.write("**Top keywords:**", ", ".join(pa.keywords()))
        words = len(pa.text.split())
        st.metric("Words", words); st.metric("Chunks", st.session_state["n"])
